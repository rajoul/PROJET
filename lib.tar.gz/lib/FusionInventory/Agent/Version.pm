package FusionInventory::Agent::Version;

use strict;
use warnings;

our $VERSION = "2.5.2-1.el7";
our $PROVIDER = "FusionInventory";
our $COMMENTS = [
    "Platform  : linux x86-01.bsys.centos.org 3.10.0-693.17.1.el7.x86_64 1 smp thu jan 25 20:13:58 utc 2018 x86_64 x86_64 x86_64 gnulinux ",
    "Build date: Tue Dec 17 08:29:52 2019 GMT"
];

1;

