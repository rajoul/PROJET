package FusionInventory::Agent::Task::NetDiscovery::Version;

use strict;
use warnings;

use constant VERSION => "4.1";

1;
