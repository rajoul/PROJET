package FusionInventory::Agent::Task::Maintenance::Version;

use strict;
use warnings;

use constant VERSION => "1.1";

1;
