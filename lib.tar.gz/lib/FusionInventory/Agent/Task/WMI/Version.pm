package FusionInventory::Agent::Task::WMI::Version;

use strict;
use warnings;

use constant VERSION => "0.3";

1;
