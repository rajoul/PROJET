package FusionInventory::Agent::Task::Collect::Version;

use strict;
use warnings;

use constant VERSION => "2.6";

1;
