package FusionInventory::Agent::Task::NetInventory::Version;

use strict;
use warnings;

use constant VERSION => "4.1";

1;
